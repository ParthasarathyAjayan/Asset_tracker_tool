from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import text

from app.database import get_db

router = APIRouter()

@router.get("/categories")
def get_categories(db: Session = Depends(get_db)):

    result = db.execute(
        text("SELECT id, name FROM categories WHERE is_active = TRUE")
    )

    categories = [
        {"id": row.id, "name": row.name}
        for row in result
    ]

    return categories
