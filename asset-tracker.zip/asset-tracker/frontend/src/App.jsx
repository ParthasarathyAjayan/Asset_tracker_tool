import { BrowserRouter, Routes, Route, useNavigate } from "react-router-dom";

import Add from "./pages/Add";
import Assign from "./pages/Assign";
import Out from "./pages/Out";
import Assets from "./pages/Assets";
import Employees from "./pages/Employees";
import Repair from "./pages/Repair";
import Clearance from "./pages/Clearance";

function Menu() {
  const navigate = useNavigate();

  const buttonStyle = {
    padding: "20px",
    fontSize: "16px",
    cursor: "pointer",
    borderRadius: "8px",
    border: "1px solid #d7bd14ff",
    background: "#0b42afff",
    color: "#ffffffff",
};


  const go = path => () => navigate(path);

  return (
    <div className="page">
      <h1 style={{ textAlign: "center" }}>
        IT Asset Tracker
      </h1>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
          gap: "20px",
          marginTop: "40px",
          maxWidth: "800px",
          marginLeft: "auto",
          marginRight: "auto"
        }}
      >
        <button style={buttonStyle} onClick={go("/add")}>ADD</button>
        <button style={buttonStyle} onClick={go("/assign")}>ASSIGN</button>
        <button style={buttonStyle} onClick={go("/out")}>OUT</button>
        <button style={buttonStyle} onClick={go("/employees")}>EMPLOYEES</button>
        <button style={buttonStyle} onClick={go("/assets")}>ASSETS</button>
        <button style={buttonStyle} onClick={go("/repair")}>REPAIR LIST</button>
        <button style={buttonStyle} onClick={go("/clearance")}>EXIT CLEARANCE</button>
      </div>
    </div>
  );
}

function BackButton() {
  const navigate = useNavigate();

  return (
    <div style={{display: "flex", justifyContent: "flex-end", padding: "20px 40px"}}>
      <button onClick={() => navigate("/")}>
        ← Back to Menu
      </button>
    </div>
  );
}


export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Menu />} />
        <Route path="/add" element={<><BackButton /><Add /></>} />
        <Route path="/assign" element={<><BackButton /><Assign /></>} />
        <Route path="/out" element={<><BackButton /><Out /></>} />
        <Route path="/assets" element={<><BackButton /><Assets /></>} />
        <Route path="/employees" element={<><BackButton /><Employees /></>} />
        <Route path="/repair" element={<><BackButton /><Repair /></>} />
        <Route path="/clearance" element={<><BackButton /><Clearance /></>} />
      </Routes>
    </BrowserRouter>
  );
}
