import { useState, useEffect } from "react";
import { fetchCategories, addAsset } from "../api/api";

export default function Add() {
  const [categories, setCategories] = useState([]);
  const [form, setForm] = useState({});
  const [msg, setMsg] = useState("");

  useEffect(() => {
    fetchCategories().then(setCategories);
  }, []);

  function update(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  async function save() {
    const res = await addAsset(form);
    setMsg(res.message || res.detail);

    // clear form after save
    setForm({});
  }

  return (
    <div className="page">
      <h2>Add Asset</h2>

      <input
        name="asset_code"
        placeholder="Barcode"
        value={form.asset_code || ""}
        onChange={update}
      />

      <select
        name="category_id"
        value={form.category_id || ""}
        onChange={update}
      >
        <option value="">Select Category</option>
        {categories.map(c => (
          <option key={c.id} value={c.id}>{c.name}</option>
        ))}
      </select>

      <input
        name="type"
        placeholder="Type (New/Repaired)"
        value={form.type || ""}
        onChange={update}
      />

      <input
        name="brand"
        placeholder="Brand"
        value={form.brand || ""}
        onChange={update}
      />

      <input
        name="model"
        placeholder="Model"
        value={form.model || ""}
        onChange={update}
      />

      <input
        name="serial_number"
        placeholder="Serial Number"
        value={form.serial_number || ""}
        onChange={update}
      />

      <input
        name="location"
        placeholder="Location"
        value={form.location || ""}
        onChange={update}
      />

      <button onClick={save}>Save Asset</button>

      <p>{msg}</p>
    </div>
  );
}
