import { useEffect, useState } from "react";
import {
  fetchEmployees,
  addEmployee,
  deactivateEmployee,
} from "../api/api";

export default function Employees() {
  const [employees, setEmployees] = useState([]);
  const [form, setForm] = useState({});
  const [msg, setMsg] = useState("");

  function load() {
    fetchEmployees().then(setEmployees);
  }

  useEffect(load, []);

  function update(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  async function save() {
    const res = await addEmployee(form);
    setMsg(res.message || res.detail);
    load();
  }

  async function deactivate(id) {
    await deactivateEmployee(id);
    load();
  }

  return (
    <div style={{ padding: 40 }}>
      <h2>Employees</h2>

      <h3>Add Employee</h3>
      <input name="employee_id" placeholder="ID" onChange={update} />
      <input name="name" placeholder="Name" onChange={update} />
      <input name="email" placeholder="Email" onChange={update} />
      <input name="location" placeholder="Location" onChange={update} />
      <button onClick={save}>Add Employee</button>
      <p>{msg}</p>

      <h3>Employee List</h3>

      <table className="compact-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Location</th>
            <th>Action</th>
          </tr>
        </thead>

        <tbody>
          {employees.map(e => (
            <tr key={e.employee_id}>
              <td>{e.employee_id}</td>
              <td>{e.name}</td>
              <td>{e.email}</td>
              <td>{e.location}</td>
              <td>
                <button onClick={() => deactivate(e.employee_id)}>
                  Deactivate
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
