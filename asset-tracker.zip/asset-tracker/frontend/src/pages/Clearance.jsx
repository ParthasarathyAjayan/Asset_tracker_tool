import { useState } from "react";
import { checkClearance, approveClearance } from "../api/api";

export default function Clearance() {
  const [emp, setEmp] = useState("");
  const [result, setResult] = useState(null);
  const [secret, setSecret] = useState("");
  const [msg, setMsg] = useState("");

  async function check() {
    const res = await checkClearance(emp);
    setResult(res);
    setMsg("");
  }

  async function approve() {
    const res = await approveClearance(emp, secret);
    setMsg(res.message || res.detail);
  }

  return (
    <div style={{ padding: 40 }}>
      <h2>Employee Exit Clearance</h2>

      <input
        placeholder="Employee ID"
        value={emp}
        onChange={e => setEmp(e.target.value)}
      />
      <button onClick={check}>Check</button>

      {result && (
        <div style={{ marginTop: 20 }}>
          <p><b>Clearance:</b> {result.clearance ? "Approved" : "Blocked"}</p>

          {result.assets && (
            <>
              <p>Pending Assets:</p>
              <ul>
                {result.assets.map(a => <li key={a}>{a}</li>)}
              </ul>
            </>
          )}
        </div>
      )}

      {result && result.clearance && (
        <>
          <input
            placeholder="Admin Secret"
            value={secret}
            onChange={e => setSecret(e.target.value)}
          />
          <button onClick={approve}>Approve Exit</button>
        </>
      )}

      <p>{msg}</p>
    </div>
  );
}
