import { useState, useEffect } from "react";
import {
  fetchAsset,
  assignAsset,
  fetchAssets,
  fetchEmployees
} from "../api/api";

export default function Assign() {
  const [search, setSearch] = useState("");
  const [asset, setAsset] = useState(null);
  const [employeeId, setEmployeeId] = useState("");
  const [employeeSearch, setEmployeeSearch] = useState("");
  const [message, setMessage] = useState("");

  const [assets, setAssets] = useState([]);
  const [employees, setEmployees] = useState([]);

  const [showList, setShowList] = useState(false);
  const [showEmployeeList, setShowEmployeeList] = useState(false);

  useEffect(() => {
    fetchAssets().then(setAssets);
    fetchEmployees().then(setEmployees);
  }, []);

  async function loadAsset(code) {
    try {
      const data = await fetchAsset(code);
      setAsset(data);
      setSearch(code);
      setMessage("");
      setShowList(false);
    } catch {
      setMessage("Asset not found");
      setAsset(null);
    }
  }

  async function assign() {
    const res = await assignAsset(search, employeeId);
    setMessage(res.message || res.detail);
  }

  const filteredAssets = assets.filter(a =>
    `${a.asset_code} ${a.model}`
      .toLowerCase()
      .includes(search.toLowerCase())
  );

  const filteredEmployees = employees.filter(e =>
    `${e.employee_id} ${e.name}`
      .toLowerCase()
      .includes(employeeSearch.toLowerCase())
  );

  return (
    <div className="page">
      <h2>Assign Asset</h2>

      <h4>Scan / Type / Select Asset</h4>

      {/* Asset search box */}
      <div style={{ position: "relative", width: "320px" }}>
        <input
          placeholder="Search or scan asset"
          value={search}
          onChange={e => {
            setSearch(e.target.value);
            setShowList(true);
          }}
          style={{ width: "100%" }}
        />

        <span
          style={{
            position: "absolute",
            right: 10,
            top: 10,
            cursor: "pointer"
          }}
          onClick={() => setShowList(!showList)}
        >
          ▼
        </span>
      </div>

      {/* Asset dropdown */}
      {showList && (
        <div
          style={{
            border: "1px solid #ccc",
            maxHeight: 150,
            overflowY: "auto",
            background: "white",
            width: "320px"
          }}
        >
          {filteredAssets.slice(0, 5).map(a => (
            <div
              key={a.asset_code}
              style={{ padding: 8, cursor: "pointer" }}
              onClick={() => loadAsset(a.asset_code)}
            >
              {a.asset_code} - {a.model}
            </div>
          ))}
        </div>
      )}

      <button onClick={() => loadAsset(search)}>Load Asset</button>

      {asset && (
        <div style={{ marginTop: 20 }}>
          <p><b>Category:</b> {asset.category}</p>
          <p><b>Status:</b> {asset.status}</p>
          <p><b>Model:</b> {asset.model}</p>
        </div>
      )}

      {asset && (
        <>
          <h4>Select Employee</h4>

          {/* Employee search */}
          <div style={{ position: "relative", width: "320px" }}>
            <input
              placeholder="Search employee"
              value={employeeSearch}
              onChange={e => {
                setEmployeeSearch(e.target.value);
                setShowEmployeeList(true);
              }}
              style={{ width: "100%" }}
            />

            <span
              style={{
                position: "absolute",
                right: 10,
                top: 10,
                cursor: "pointer"
              }}
              onClick={() =>
                setShowEmployeeList(!showEmployeeList)
              }
            >
              ▼
            </span>
          </div>

          {showEmployeeList && (
            <div
              style={{
                border: "1px solid #ccc",
                maxHeight: 150,
                overflowY: "auto",
                background: "white",
                width: "320px"
              }}
            >
              {filteredEmployees.slice(0, 5).map(emp => (
                <div
                  key={emp.employee_id}
                  style={{ padding: 8, cursor: "pointer" }}
                  onClick={() => {
                    setEmployeeId(emp.employee_id);
                    setEmployeeSearch(
                      `${emp.employee_id} - ${emp.name}`
                    );
                    setShowEmployeeList(false);
                  }}
                >
                  {emp.employee_id} - {emp.name}
                </div>
              ))}
            </div>
          )}

          <button onClick={assign}>Assign Asset</button>
        </>
      )}

      <p>{message}</p>
    </div>
  );
}
