import { useEffect, useState } from "react";
import { fetchRepairList } from "../api/api";

export default function Repair() {
  const [items, setItems] = useState([]);

  useEffect(() => {
    fetchRepairList().then(setItems);
  }, []);

  return (
    <div style={{ padding: 40 }}>
      <h2>Repair List</h2>

      <table border="1" cellPadding="8">
        <thead>
          <tr>
            <th>Asset Code</th>
            <th>Repair Assignee</th>
            <th>Start Date</th>
          </tr>
        </thead>

        <tbody>
          {items.map(a => (
            <tr key={a.asset_code}>
              <td>{a.asset_code}</td>
              <td>{a.name || "Unknown"}</td>
              <td>{a.repair_start_date}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
