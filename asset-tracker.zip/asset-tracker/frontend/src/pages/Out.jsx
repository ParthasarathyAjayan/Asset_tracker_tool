import { useState } from "react";
import {
  returnAsset,
  sendToRepair,
  markMissing,
  retireAsset,
} from "../api/api";

export default function Out() {
  const [barcode, setBarcode] = useState("");
  const [action, setAction] = useState("return");
  const [employee, setEmployee] = useState("");
  const [secret, setSecret] = useState("");
  const [msg, setMsg] = useState("");

  async function execute() {
    let res;

    if (action === "return") {
      res = await returnAsset(barcode);
    }

    if (action === "repair") {
      res = await sendToRepair(barcode, employee);
    }

    if (action === "missing") {
      res = await markMissing(barcode);
    }

    if (action === "retire") {
      res = await retireAsset(barcode, secret);
    }

    setMsg(res.message || res.detail);
  }

  return (
    <div style={{ padding: 40 }}>
      <h2>OUT Asset</h2>

      <input
        placeholder="Barcode"
        value={barcode}
        onChange={e => setBarcode(e.target.value)}
      />
      <br /><br />

      <select value={action} onChange={e => setAction(e.target.value)}>
        <option value="return">Return</option>
        <option value="repair">Repair</option>
        <option value="missing">Missing</option>
        <option value="retire">Retire</option>
      </select>

      {action === "repair" && (
        <>
          <br /><br />
          <input
            placeholder="Repair Employee ID"
            value={employee}
            onChange={e => setEmployee(e.target.value)}
          />
        </>
      )}

      {action === "retire" && (
        <>
          <br /><br />
          <input
            placeholder="Admin Secret"
            value={secret}
            onChange={e => setSecret(e.target.value)}
          />
        </>
      )}

      <br /><br />
      <button onClick={execute}>Execute</button>

      <p>{msg}</p>
    </div>
  );
}
