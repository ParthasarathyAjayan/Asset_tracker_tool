import { useEffect, useState } from "react";
import { fetchAssets } from "../api/api";

export default function Assets() {
  const [assets, setAssets] = useState([]);

  useEffect(() => {
    fetchAssets().then(setAssets);
  }, []);

  return (
    <div className="page">
      <h2>All Assets</h2>

      <table>
        <thead>
          <tr>
            <th>Code</th>
            <th>Category</th>
            <th>Status</th>
            <th>Brand</th>
            <th>Model</th>
            <th>Location</th>
            <th>Assigned To</th>
          </tr>
        </thead>

        <tbody>
          {assets.map(a => (
            <tr key={a.asset_code}>
              <td>{a.asset_code}</td>
              <td>{a.category}</td>
              <td>{a.status}</td>
              <td>{a.brand}</td>
              <td>{a.model}</td>
              <td>{a.location}</td>
              <td>
                {a.employee_id
                  ? `${a.employee_id} - ${a.employee_name || ""}`
                  : "Unassigned"}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
